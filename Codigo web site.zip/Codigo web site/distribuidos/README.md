# distribuidos
Este trabalho visa implementar uma aplicação distribuída na qual seja possível aplicar muitos dos conceitos teóricos visto na disciplina CSI433 - Sistemas Distribuidos

# Firebase docs:

https://firebase.google.com/docs/hosting/deploying

# Clonando o repositorio:

git clone git@github.com:hcdias/distribuidos.git

